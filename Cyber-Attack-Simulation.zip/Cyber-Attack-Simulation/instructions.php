```php
<?php

define( 'DVWA_WEB_PAGE_TO_ROOT', '' );
require_once DVWA_WEB_PAGE_TO_ROOT . 'dvwa/includes/dvwaPage.inc.php';

dvwaPageStartup( array() );

$page = dvwaPageNewGrab();
$page[ 'title' ]   = 'Cyber Attack Simulation - Instructions' . $page[ 'title_separator' ].$page[ 'title' ];
$page[ 'page_id' ] = 'instructions';

/* เลือกภาษา */
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'th';

/* ================= ภาษาไทย ================= */

$content_th = '

<h1>ยินดีต้อนรับสู่ Cyber Attack Simulation</h1>

<p>
Cyber Attack Simulation เป็นระบบเว็บแอปพลิเคชันที่พัฒนาด้วย PHP และ MySQL
เพื่อใช้เป็นสภาพแวดล้อมสำหรับการเรียนรู้ด้านความปลอดภัยของเว็บแอปพลิเคชัน
โดยผู้ใช้สามารถทดลองโจมตีช่องโหว่ของระบบได้ในสภาพแวดล้อมที่ปลอดภัย
</p>

<p>
ระบบนี้ถูกออกแบบให้ผู้เรียนเข้าใจเส้นทางของข้อมูลในระบบ
ตั้งแต่ <strong>Input → Processing → Output → Security Impact</strong>
และเรียนรู้วิธีป้องกันช่องโหว่ที่เกิดขึ้น
</p>

<hr>

<h2>โมดูลการโจมตีพื้นฐาน</h2>

<ul>
<li><b>SQL Injection</b> - การโจมตีฐานข้อมูลผ่านช่องโหว่ของ Query</li>
<li><b>Cross Site Scripting (XSS)</b> - การฝัง Script อันตรายลงในเว็บไซต์</li>
<li><b>Command Injection</b> - การสั่งรันคำสั่งระบบผ่าน input</li>
<li><b>CSRF Attack</b> - การปลอมคำสั่งจากผู้ใช้ที่ล็อกอินอยู่</li>
<li><b>Brute Force</b> - การเดารหัสผ่านแบบอัตโนมัติ</li>
<li><b>File Upload Vulnerability</b> - การอัปโหลดไฟล์อันตรายเข้าสู่ระบบ</li>
</ul>

<hr>

<h2>โมดูลเพิ่มเติม (Cyber Attack Simulation)</h2>

<ul>
<li><b>Open HTTP Redirect</b> - การเปลี่ยนเส้นทางเว็บไซต์ไปยังเว็บอันตราย</li>

<li><b>Cryptography</b> - ตัวอย่างการเข้ารหัสที่ไม่ปลอดภัย</li>

<li><b>IDOR (Insecure Direct Object Reference)</b> - การเข้าถึงข้อมูลที่ไม่ควรเข้าถึงได้</li>

<li><b>Simulation</b> - สถานการณ์จำลองการโจมตีจริง</li>

<li><b>Incident Timeline</b> - การแสดงลำดับเหตุการณ์ของการโจมตี</li>

</ul>

<hr>

<h2>วัตถุประสงค์ของระบบ</h2>

<ul>
<li>ใช้เป็นสื่อการเรียนรู้ด้าน Cyber Security</li>
<li>ช่วยให้เข้าใจช่องโหว่ของเว็บแอปพลิเคชัน</li>
<li>ฝึกการวิเคราะห์และทดสอบความปลอดภัย</li>
<li>จำลองสถานการณ์ Cyber Attack</li>
</ul>

<hr>

<p>
<strong>คำเตือน :</strong> เว็บไซต์นี้มีช่องโหว่ด้านความปลอดภัยโดยตั้งใจ
เพื่อใช้สำหรับการศึกษาเท่านั้น ห้ามนำไปใช้งานบนระบบจริง
</p>


<hr>

<h2>แหล่งอ้างอิง</h2>

<ul>
<li>
OWASP Foundation. OWASP Top 10 Web Application Security Risks  
<a href="https://owasp.org/www-project-top-ten/" target="_blank">
https://owasp.org/www-project-top-ten/
</a>
</li>

<li>
Damn Vulnerable Web Application (DVWA) Project  
<a href="https://github.com/digininja/DVWA" target="_blank">
https://github.com/digininja/DVWA
</a>
</li>

<li>
PortSwigger Web Security Academy  
<a href="https://portswigger.net/web-security" target="_blank">
https://portswigger.net/web-security
</a>
</li>

</ul>

';

/* ================= English ================= */

$content_en = '

<h1>Welcome to Cyber Attack Simulation</h1>

<p>
Cyber Attack Simulation is a PHP/MySQL web application designed
to provide a safe environment for learning web application security.
Users can practice exploiting vulnerabilities in a controlled lab environment.
</p>

<p>
The system demonstrates how data flows through a web application:
<strong>Input → Processing → Output → Security Impact</strong>.
Students can learn both attack techniques and defense concepts.
</p>

<hr>

<h2>Basic Attack Modules</h2>

<ul>
<li><b>SQL Injection</b> - Database injection vulnerabilities</li>
<li><b>Cross Site Scripting (XSS)</b> - Injecting malicious scripts</li>
<li><b>Command Injection</b> - Executing system commands via input</li>
<li><b>CSRF Attack</b> - Forged requests from authenticated users</li>
<li><b>Brute Force</b> - Automated password guessing</li>
<li><b>File Upload Vulnerability</b> - Uploading malicious files</li>
</ul>

<hr>

<h2>Extended Cyber Security Modules</h2>

<ul>
<li><b>Open HTTP Redirect</b> - Redirect manipulation attacks</li>

<li><b>Cryptography</b> - Weak encryption demonstrations</li>

<li><b>IDOR (Insecure Direct Object Reference)</b> - Unauthorized data access</li>

<li><b>Simulation</b> - Realistic cyber attack scenarios</li>

<li><b>Incident Timeline</b> - Attack timeline and forensic analysis</li>

</ul>

<hr>

<h2>Project Goals</h2>

<ul>
<li>Provide a cybersecurity learning platform</li>
<li>Demonstrate real-world web vulnerabilities</li>
<li>Improve awareness of web security risks</li>
<li>Simulate cyber attack scenarios</li>
</ul>

<hr>

<p>
<strong>Warning :</strong> This application intentionally contains vulnerabilities
and must only be used for educational purposes.
</p>

<hr>

<h2>References</h2>

<ul>

<li>
OWASP Foundation. OWASP Top 10 Web Application Security Risks  
<a href="https://owasp.org/www-project-top-ten/" target="_blank">
https://owasp.org/www-project-top-ten/
</a>
</li>

<li>
Damn Vulnerable Web Application (DVWA) Project  
<a href="https://github.com/digininja/DVWA" target="_blank">
https://github.com/digininja/DVWA
</a>
</li>

<li>
PortSwigger Web Security Academy  
<a href="https://portswigger.net/web-security" target="_blank">
https://portswigger.net/web-security
</a>
</li>

</ul>

';

/* เลือกภาษา */
$content = ($lang == 'en') ? $content_en : $content_th;

$page['body'] .= '

<div class="body_padded">

<div style="float:right; font-size:14px;">
ภาษา : 
<a href="?lang=th">TH</a> |
<a href="?lang=en">EN</a>
</div>

'.$content.'

</div>



';

dvwaHtmlEcho( $page );

?>
```
