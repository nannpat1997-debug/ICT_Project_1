<?php

define( 'DVWA_WEB_PAGE_TO_ROOT', '' );
require_once DVWA_WEB_PAGE_TO_ROOT . 'dvwa/includes/dvwaPage.inc.php';

dvwaPageStartup( array( ) );

$page = dvwaPageNewGrab();
$page[ 'title' ]   = 'Cyber Attack Simulation Setup' . $page[ 'title_separator' ].$page[ 'title' ];
$page[ 'page_id' ] = 'setup';

if( isset( $_POST[ 'create_db' ] ) ) {

	// Anti-CSRF
	if (array_key_exists ("session_token", $_SESSION)) {
		$session_token = $_SESSION[ 'session_token' ];
	} else {
		$session_token = "";
	}

	checkToken( $_REQUEST[ 'user_token' ], $session_token, 'setup.php' );

	if( $DBMS == 'MySQL' ) {
		include_once DVWA_WEB_PAGE_TO_ROOT . 'dvwa/includes/DBMS/MySQL.php';
	}
	elseif($DBMS == 'PGSQL') {
		dvwaMessagePush( 'PostgreSQL is not yet fully supported.' );
		dvwaPageReload();
	}
	else {
		dvwaMessagePush( 'ERROR: Invalid database selected.' );
		dvwaPageReload();
	}
}

// Anti-CSRF
generateSessionToken();

$database_type_name = "Unknown";
if( $DBMS == 'MySQL' ) {
	$database_type_name = "MySQL / MariaDB";
} elseif($DBMS == 'PGSQL') {
	$database_type_name = "PostgreSQL";
}

$git_ref = "<em>Unknown</em><br><br>";
$mod_rewrite = "<em>Unknown</em><br>";

if (PHP_OS == "Linux") {
	if (is_dir (".git")) {
		$git_log = shell_exec ("git -c 'safe.directory=*' log -1");
		if (!is_null ($git_log)) {
			$tmp = explode ("\n", $git_log);
			$date = str_replace ("Date: ", "Date: <em>", $tmp[2]);
			$git_ref = "<ul><li>" . str_replace ("commit ", "Git reference: <em>", $tmp[0]) . "</em></li><li>" . $date . "</em></li></ul>";
		}
	}

	$out = shell_exec ("apachectl -M | grep rewrite_module");
	if ($out == "") {
		$mod_rewrite = "<em><span class='failure'>Not Enabled</span></em><br>";
	} else {
		$mod_rewrite = "<em><span class='success'>Enabled</span></em><br>";
	}
}

if (!is_dir ("./vulnerabilities/api/vendor")) {
	$vendor = "<em><span class='failure'>Not Installed</span></em><br><br>";
} else {
	$vendor = "<em><span class='success'>Installed</span></em><br>";
}

$page['body'] .= "

<div class=\"body_padded\">

<h1>Cyber Attack Simulation - System Setup</h1>

<p>
This page is used to initialize the database for the <strong>Cyber Attack Simulation</strong> system.
The platform is designed for learning and practicing web application security concepts.
It is inspired by DVWA and extended to simulate real cyber attack scenarios.
</p>

<p>
When you click the <strong>Create / Reset Database</strong> button,
the system will create a new database or reset all existing data
to prepare the environment for security testing modules.
</p>

<hr />

<h2>System Environment Check</h2>

<em>Server</em><br />
{$DVWAOS}<br /><br />

<em>Web Server</em><br />
{$SERVER_NAME}<br /><br />

mod_rewrite: {$mod_rewrite}
(mod_rewrite is required for some modules in the system)<br /><br />

<em>PHP</em><br />
PHP Version: <em>" . phpversion() . "</em><br />
{$phpDisplayErrors}<br />
{$phpURLInclude}<br />
{$phpURLFopen}<br />
{$phpGD}<br />
{$phpMySQL}<br />
{$phpPDO}<br />

<br />

<em>Database</em><br />
Database Type: <em>{$database_type_name}</em><br />
{$MYSQL_USER}<br />
{$MYSQL_PASS}<br />
{$MYSQL_DB}<br />
{$MYSQL_SERVER}<br />

<br />

<em>API Module</em><br />
Vendor Files: {$vendor}

<br /><br />

<hr />

<h2>Database Initialization</h2>

<p>
Click the button below to create or reset the database for the Cyber Attack Simulation system.
</p>

<form action=\"#\" method=\"post\">
	<input name=\"create_db\" type=\"submit\" value=\"Create / Reset Database\">
	" . tokenField() . "
</form>

<br />

<hr />

<h2>References</h2>

<ul>
<li>
OWASP Top 10  
<a href=\"https://owasp.org/www-project-top-ten/\" target=\"_blank\">
https://owasp.org/www-project-top-ten/
</a>
</li>

<li>
Damn Vulnerable Web Application (DVWA)  
<a href=\"https://github.com/digininja/DVWA\" target=\"_blank\">
https://github.com/digininja/DVWA
</a>
</li>

<li>
PortSwigger Web Security Academy  
<a href=\"https://portswigger.net/web-security\" target=\"_blank\">
https://portswigger.net/web-security
</a>
</li>
</ul>

<br />

<p>
<strong>Warning :</strong> This system intentionally contains security vulnerabilities
for educational and research purposes only.
</p>

</div>

";

dvwaHtmlEcho( $page );

?>